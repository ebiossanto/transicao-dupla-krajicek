import Mathlib

namespace FPDP

/-- Affine second-moment update. -/
def step (rho c x : ℝ) : ℝ := rho * x + c

/-- The unique algebraic fixed point of x ↦ rho*x+c when rho ≠ 1. -/
theorem fixedPoint_affine {rho c x : ℝ} (h : x = step rho c x)
    (hrho : rho ≠ 1) : x = c / (1 - rho) := by
  unfold step at h
  field_simp
  linarith

/-- DFA bridge fixed point. -/
theorem fpdp_dfa {rho p D : ℝ} (h : D = rho * D + rho * p^2)
    (hrho : rho ≠ 1) : D = rho / (1-rho) * p^2 := by
  have h1 : D = (rho * p^2) / (1-rho) := by
    apply fixedPoint_affine (rho := rho) (c := rho*p^2)
    · simpa [step] using h
    · exact hrho
  rw [h1]
  ring

/-- General two-gate PFA bridge: injection is governed by acquisition marginal sU. -/
theorem fpdp_pfa_general {rho sU e F : ℝ}
    (h : F = rho * F + sU * e^2) (hrho : rho ≠ 1) :
    F = sU / (1-rho) * e^2 := by
  have h1 : F = (sU * e^2) / (1-rho) := by
    apply fixedPoint_affine (rho := rho) (c := sU*e^2)
    · simpa [step] using h
    · exact hrho
  rw [h1]
  ring

/-- Symmetric independent gates recover sU = sqrt(rho). -/
theorem fpdp_pfa_symmetric {rho s e F : ℝ}
    (hs : s^2 = rho) (h : F = rho * F + s * e^2)
    (hrho : rho ≠ 1) : F = s / (1-rho) * e^2 := by
  exact fpdp_pfa_general h hrho

end FPDP
