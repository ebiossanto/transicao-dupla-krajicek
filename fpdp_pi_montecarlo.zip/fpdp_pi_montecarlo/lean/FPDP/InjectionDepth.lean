import Mathlib

namespace FPDP

/-- Algebraic PI theorem, stated with an abstract injection probability alpha.
    The probabilistic layer proves alpha = rho^(ell/m) under i.i.d. equal gates. -/
theorem injectionDepth_fixedPoint {rho alpha sigma V : ℝ}
    (h : V = rho * V + alpha * sigma^2)
    (hrho : rho ≠ 1) :
    V = alpha / (1-rho) * sigma^2 := by
  have h1 : V = (alpha*sigma^2)/(1-rho) := by
    field_simp
    linarith
  rw [h1]
  ring

/-- Threshold algebra for a generic exponent gap delta > 0 is intentionally
    separated from real-power probability semantics. -/
theorem threshold_equiv {q c z : ℝ}
    (hq : 0 ≤ q) (hc : c < 1) (hz : 0 < z) :
    (1 - q^2 / z = c) ↔ (z = q^2 / (1-c)) := by
  constructor <;> intro h
  · field_simp at h ⊢
    nlinarith
  · rw [h]
    field_simp
    nlinarith

end FPDP
