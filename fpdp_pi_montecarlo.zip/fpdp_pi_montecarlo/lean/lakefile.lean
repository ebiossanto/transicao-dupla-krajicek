import Lake
open Lake DSL

package fpdp where
  moreLeanArgs := #["-DautoImplicit=false"]

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git"

@[default_target]
lean_lib FPDP where
  roots := #[`FPDP.Bridge, `FPDP.InjectionDepth]
