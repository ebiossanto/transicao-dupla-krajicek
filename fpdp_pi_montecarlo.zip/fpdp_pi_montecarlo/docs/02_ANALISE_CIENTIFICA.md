# Análise científica e contribuição candidata

## Resultado consolidado

A fórmula mais geral derivada pelo modelo de duas portas é

\[
D=\frac{\rho}{1-\rho}p^2,
\qquad
F=\frac{s_U}{1-\rho}e^2,
\]

com

\[
\rho=\Pr(U=1,V=1).
\]

A forma `sqrt(rho)` é um corolário, não o teorema mais geral:

\[
F=\frac{\sqrt\rho}{1-\rho}e^2
\]

somente quando as portas são independentes e simétricas.

## Avanço conceitual

O desenvolvimento produz três conclusões relevantes:

1. **Profundidade de injeção:** o expoente `ell/m` representa a fração da cadeia atravessada antes da entrada do erro.
2. **Não-identificabilidade por rho:** em portas assimétricas/correlacionadas, `rho` não determina sozinho a penalidade PFA.
3. **Separação marginal-conjunta:** a persistência depende da probabilidade conjunta; a injeção antecipada depende de uma marginal ou probabilidade parcial.

O terceiro ponto é particularmente aplicável. Ele mostra que observar apenas a taxa fim a fim pode ser insuficiente para escolher entre estratégias preditivas e reativas.

## Limites

A validade da derivação depende de:

- pares de portas i.i.d. no tempo;
- ruídos centrados e de segunda ordem finita;
- independência entre ruído, portas e passado;
- injeção PFA na porta de aquisição;
- regime estacionário `rho < 1`;
- para cascatas, ortogonalidade entre entrada e residual.

Quando as portas possuem memória, deve-se usar um sistema de momentos condicionais. Quando entrada e residual são correlacionados, o fator local recebe um termo de covariância.

## Originalidade

Não se reivindica que processos Bernoulli, filtragem intermitente, pontos fixos lineares ou produtos de razões sejam novos. A contribuição candidata é a organização conjunta:

- arquitetura de portas;
- profundidade de injeção;
- expoentes de carga;
- limiares TGL;
- composição TGH/TLGH;
- certificados para assimetria e correlação.

Antes de qualquer alegação externa, é necessária pesquisa sistemática de anterioridade e comparação com filtragem intermitente, controle em rede, confiabilidade multiporta e cascatas de variância.
