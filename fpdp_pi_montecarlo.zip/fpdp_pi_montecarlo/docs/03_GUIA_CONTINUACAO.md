# Guia de continuidade

## Objetivo imediato

Transformar a derivação abstrata em um resultado aplicado e falsificável.

## P1: validar a implementação

```bash
python -m pip install -e .
pytest -q
python scripts/run_experiments.py
```

Critérios:

- todos os testes passam;
- erros Monte Carlo diminuem aproximadamente como `1/sqrt(N)`;
- o caso simétrico recupera `s_U=sqrt(rho)`;
- casos assimétricos rejeitam a forma de raiz quadrada.

## P2: ampliar o simulador

1. portas Markovianas tipo Gilbert-Elliott;
2. ruído com viés;
3. ruído dependente da carga;
4. correlação entre entrada e residual;
5. cascatas de múltiplos estágios;
6. intervalos de confiança por replicações independentes.

## P3: formalização

O diretório `lean/` contém o núcleo algébrico. Próximas provas:

1. solução finita da recorrência;
2. convergência geométrica;
3. versão de `m` portas com expoente racional;
4. TGL por profundidade;
5. TGH em produtos positivos.

## P4: domínio piloto

Recomendação: controle ou estimação em rede com dois canais observáveis.

Dados mínimos:

- sucesso do canal sensor-controlador;
- sucesso do canal controlador-atuador;
- coincidência temporal dos sucessos;
- resíduos de previsão e reação;
- variância da grandeza propagada.

## P5: critérios de falsificação

O modelo deve ser rejeitado ou corrigido se:

- `D_t` ou `F_t` não obedecerem aproximadamente a recorrências afins;
- houver forte memória temporal não modelada;
- `e` e `p` variarem sistematicamente com as portas;
- a covariância entrada-residual não for desprezível;
- a métrica propagada mudar entre estágios.

## P6: publicação

Antes de submeter artigo:

- auditoria bibliográfica documentada;
- formalização compilada;
- simulação com intervalos de confiança;
- ao menos um conjunto de dados real ou bancada experimental;
- seção explícita de non-claims.
