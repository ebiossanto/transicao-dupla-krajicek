# Derivação, experimentos e resultados

## 1. Modelo

Duas portas Bernoulli, aquisição `U` e confirmação `V`, possuem marginais

\[
s_U=\Pr(U=1),\qquad s_V=\Pr(V=1),
\]

e probabilidade conjunta

\[
\rho=\Pr(U=1,V=1).
\]

A persistência é `B=UV`. As dinâmicas são

\[
X_{t+1}=B_t(X_t+\xi_t),
\qquad
Y_{t+1}=B_tY_t+U_t\eta_t.
\]

Com ruídos centrados, independentes do passado e variâncias `p²` e `e²`, obtêm-se

\[
D_{t+1}=\rho D_t+\rho p^2,
\qquad
F_{t+1}=\rho F_t+s_Ue^2.
\]

Logo, para `rho < 1`,

\[
D_\infty=\frac{\rho}{1-\rho}p^2,
\qquad
F_\infty=\frac{s_U}{1-\rho}e^2.
\]

## 2. Caso independente e simétrico

Se `s_U=s_V=s` e as portas são independentes,

\[
\rho=s^2,
\qquad s=\sqrt\rho.
\]

Portanto,

\[
F_\infty=\frac{\sqrt\rho}{1-\rho}e^2.
\]

Este é o caso FPDP original.

## 3. Portas assimétricas

Se as portas são independentes, mas `s_U != s_V`, então

\[
\rho=s_Us_V,
\]

porém

\[
F_\infty=\frac{s_U}{1-s_Us_V}e^2.
\]

A raiz quadrada deixa de ser válida. Isso prova que `sqrt(rho)` não é universal: ela codifica **independência e simetria das portas**.

Uma consequência nova é a identificação parcial: conhecer apenas `rho` não basta para prever `F`; também é necessário conhecer `s_U`, ou uma hipótese estrutural que o determine.

## 4. Portas correlacionadas

Para Bernoulli correlacionadas,

\[
\rho=s_Us_V+c\sqrt{s_U(1-s_U)s_V(1-s_V)},
\]

onde `c=Corr(U,V)`, respeitando os limites de Fréchet-Hoeffding.

As fórmulas estacionárias continuam sendo

\[
D_\infty=\frac{\rho}{1-\rho}p^2,
\qquad
F_\infty=\frac{s_U}{1-\rho}e^2,
\]

desde que os pares de portas sejam i.i.d. no tempo e independentes dos ruídos e do estado passado.

A correlação altera `rho`, logo altera a persistência e o denominador comum. Contudo, a intensidade de injeção PFA continua sendo governada pela marginal `s_U`.

## 5. Generalização PI

Para `m` portas independentes com probabilidade comum `s`, a persistência completa possui

\[
\rho=s^m.
\]

Se a inovação entra após `ell` portas,

\[
\Pr(C^{(\ell)}=1)=s^\ell=\rho^{\ell/m}.
\]

Da recorrência

\[
V_{t+1}=\rho V_t+\rho^{\ell/m}\sigma^2
\]

segue

\[
V_{\ell,m}=\frac{\rho^{\ell/m}}{1-\rho}\sigma^2.
\]

Este é o Teorema da Profundidade de Injeção.

## 6. Conclusão experimental

Os experimentos reproduzíveis em `results/` mostram concordância entre Monte Carlo e as fórmulas exatas para:

- portas independentes simétricas;
- portas independentes assimétricas;
- correlação positiva;
- correlação negativa.

O critério de teste automatizado exige erro relativo inferior a 4,5% em amostras menores usadas no CI. A execução principal usa 120.000 trajetórias e 900 iterações de aquecimento.
