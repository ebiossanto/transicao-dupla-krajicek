# Referências de contexto e non-claims

## Referências de contexto

1. Sinopoli et al., *Kalman Filtering with Intermittent Observations*. Trabalho clássico sobre covariância de erro sob chegadas aleatórias de observações.
2. Kar, Sinopoli e Moura, *Kalman Filtering with Intermittent Observations: Weak Convergence to a Stationary Distribution*.
3. Mo e Sinopoli, trabalhos sobre valores críticos e caudas em filtragem com perdas Bernoulli/Markovianas.
4. Literatura de controle preditivo em rede com perdas de pacotes e atrasos aleatórios.
5. Literatura de bullwhip multiestágio e razões cumulativas de variância.

## Non-claims

- O pacote não prova originalidade bibliográfica.
- O caso `sqrt(rho)` não é universal.
- `rho` não é automaticamente utilização, carga ou taxa de chegada.
- Validação Monte Carlo não substitui prova; ela testa a implementação.
- A formalização Lean fornecida não foi compilada neste ambiente, porque Lean 4 não estava instalado.
- O modelo ainda não foi validado em dados reais.
- A interpretação bullwhip exige uma métrica de variância consistente entre estágios.
