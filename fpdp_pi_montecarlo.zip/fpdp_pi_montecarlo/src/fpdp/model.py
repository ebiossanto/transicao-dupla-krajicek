"""Double-gate stochastic bridge model.

DFA: X_(t+1) = B_t (X_t + xi_t)
PFA: Y_(t+1) = B_t Y_t + U_t eta_t
where B_t = U_t V_t.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np


def feasible_joint_interval(s_u: float, s_v: float) -> tuple[float, float]:
    """Frechet-Hoeffding interval for rho=P(U=1,V=1)."""
    _prob(s_u, "s_u")
    _prob(s_v, "s_v")
    return max(0.0, s_u + s_v - 1.0), min(s_u, s_v)


def joint_from_correlation(s_u: float, s_v: float, corr: float) -> float:
    """Convert Bernoulli correlation to joint success probability."""
    _prob(s_u, "s_u")
    _prob(s_v, "s_v")
    if not -1.0 <= corr <= 1.0:
        raise ValueError("corr must be in [-1,1]")
    scale = math.sqrt(s_u * (1-s_u) * s_v * (1-s_v))
    rho = s_u * s_v + corr * scale
    lo, hi = feasible_joint_interval(s_u, s_v)
    if rho < lo - 1e-12 or rho > hi + 1e-12:
        raise ValueError(f"infeasible correlation; joint={rho}, feasible=[{lo},{hi}]")
    return min(max(rho, lo), hi)


def correlation_from_joint(s_u: float, s_v: float, rho: float) -> float:
    _validate_gate_law(s_u, s_v, rho)
    scale = math.sqrt(s_u * (1-s_u) * s_v * (1-s_v))
    if scale == 0:
        return 0.0
    return (rho - s_u*s_v) / scale


@dataclass(frozen=True)
class GateLaw:
    s_u: float
    s_v: float
    rho: float

    def __post_init__(self):
        _validate_gate_law(self.s_u, self.s_v, self.rho)

    @classmethod
    def independent(cls, s_u: float, s_v: float) -> "GateLaw":
        return cls(s_u=s_u, s_v=s_v, rho=s_u*s_v)

    @classmethod
    def symmetric_correlated(cls, s: float, corr: float) -> "GateLaw":
        return cls(s, s, joint_from_correlation(s, s, corr))

    @property
    def corr(self) -> float:
        return correlation_from_joint(self.s_u, self.s_v, self.rho)

    @property
    def probabilities(self) -> np.ndarray:
        """Probabilities for states (U,V)=(0,0),(0,1),(1,0),(1,1)."""
        p11 = self.rho
        p10 = self.s_u - p11
        p01 = self.s_v - p11
        p00 = 1.0 - self.s_u - self.s_v + p11
        return np.array([p00, p01, p10, p11], dtype=float)


def theoretical_variances(gates: GateLaw, p: float, e: float) -> dict[str, float]:
    """Exact stationary second moments under centered independent innovations."""
    if p < 0 or e < 0:
        raise ValueError("p and e must be nonnegative")
    if gates.rho >= 1:
        raise ValueError("stationarity requires rho < 1")
    den = 1.0 - gates.rho
    dfa = gates.rho * p*p / den
    pfa = gates.s_u * e*e / den
    return {"D": dfa, "F": pfa, "mitigation": 1.0 - pfa/dfa if dfa > 0 else float('nan')}


def simulate_double_gate(
    gates: GateLaw,
    p: float,
    e: float,
    *,
    paths: int = 100_000,
    burn_in: int = 800,
    seed: int = 11,
) -> dict[str, float]:
    """Vectorized Monte Carlo approximation of stationary variances.

    Uses independent Gaussian innovations. Only their centered second moments are
    needed by the analytical theorem; Gaussianity is a simulation choice.
    """
    if paths < 100 or burn_in < 1:
        raise ValueError("paths >= 100 and burn_in >= 1 required")
    theory = theoretical_variances(gates, p, e)
    rng = np.random.default_rng(seed)
    x = np.zeros(paths, dtype=np.float64)
    y = np.zeros(paths, dtype=np.float64)
    probs = gates.probabilities
    cdf = np.cumsum(probs)

    for _ in range(burn_in):
        z = rng.random(paths)
        state = np.searchsorted(cdf, z, side="right")
        # state: 0=(0,0), 1=(0,1), 2=(1,0), 3=(1,1)
        u = state >= 2
        b = state == 3
        xi = rng.normal(0.0, p, size=paths)
        eta = rng.normal(0.0, e, size=paths)
        x = b * (x + xi)
        y = b * y + u * eta

    d_hat = float(np.var(x, ddof=0))
    f_hat = float(np.var(y, ddof=0))
    return {
        "D_hat": d_hat,
        "F_hat": f_hat,
        "D_theory": theory["D"],
        "F_theory": theory["F"],
        "D_rel_error": abs(d_hat-theory["D"])/theory["D"] if theory["D"] else 0.0,
        "F_rel_error": abs(f_hat-theory["F"])/theory["F"] if theory["F"] else 0.0,
        "mitigation_hat": 1.0-f_hat/d_hat if d_hat > 0 else float('nan'),
        "mitigation_theory": theory["mitigation"],
    }


def _prob(x: float, name: str) -> None:
    if not 0.0 <= x <= 1.0:
        raise ValueError(f"{name} must be in [0,1]")


def _validate_gate_law(s_u: float, s_v: float, rho: float) -> None:
    _prob(s_u, "s_u")
    _prob(s_v, "s_v")
    _prob(rho, "rho")
    lo, hi = feasible_joint_interval(s_u, s_v)
    if not lo - 1e-12 <= rho <= hi + 1e-12:
        raise ValueError(f"rho={rho} outside Frechet interval [{lo},{hi}]")
    if rho >= 1.0:
        raise ValueError("rho=1 has no finite stationary variance")
