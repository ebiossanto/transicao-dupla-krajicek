# Changelog

## 0.1.0 - 2026-10-15

- Implementada simulação Monte Carlo vetorizada.
- Adicionadas portas independentes simétricas e assimétricas.
- Adicionado modelo Bernoulli correlacionado por probabilidade conjunta.
- Demonstrada fórmula geral `F=s_U e²/(1-rho)`.
- Identificado que `sqrt(rho)` exige independência e simetria.
- Adicionados testes de Fréchet-Hoeffding e Monte Carlo.
- Adicionada formalização Lean 4 dos pontos fixos FPDP/PI.
- Adicionados documentos de derivação, análise e continuidade.
