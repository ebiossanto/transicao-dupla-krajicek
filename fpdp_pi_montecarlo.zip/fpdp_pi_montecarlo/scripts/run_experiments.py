from pathlib import Path
import csv, json, sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from fpdp import GateLaw, simulate_double_gate

SCENARIOS = [
    ("independent_symmetric", GateLaw.independent(0.70, 0.70), 0.60, 0.35),
    ("independent_asymmetric_U_high", GateLaw.independent(0.85, 0.55), 0.60, 0.35),
    ("independent_asymmetric_U_low", GateLaw.independent(0.55, 0.85), 0.60, 0.35),
    ("correlated_positive", GateLaw.symmetric_correlated(0.70, 0.45), 0.60, 0.35),
    ("correlated_negative", GateLaw.symmetric_correlated(0.70, -0.35), 0.60, 0.35),
]

def main():
    out=[]
    for i,(name,g,p,e) in enumerate(SCENARIOS):
        row={
            "scenario":name,"s_u":g.s_u,"s_v":g.s_v,"rho":g.rho,"corr":g.corr,
            "p":p,"e":e,"paths":120000,"burn_in":900,"seed":11+i,
        }
        row.update(simulate_double_gate(g,p,e,paths=row["paths"],burn_in=row["burn_in"],seed=row["seed"]))
        out.append(row)
        print(name, "Derr=", f'{row["D_rel_error"]:.4%}', "Ferr=", f'{row["F_rel_error"]:.4%}')
    result_dir=ROOT/'results'; result_dir.mkdir(exist_ok=True)
    (result_dir/'monte_carlo_results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    with (result_dir/'monte_carlo_results.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(out[0]))
        writer.writeheader(); writer.writerows(out)

if __name__=='__main__': main()
