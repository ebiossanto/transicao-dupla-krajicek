# FPDP/PI: simulação Monte Carlo e formalização

Pacote de desenvolvimento da **derivação por portas estocásticas** das fórmulas-ponte:

\[
D=\frac{\rho}{1-\rho}p^2,
\qquad
F=\frac{s_U}{1-\rho}e^2,
\qquad
\rho=\Pr(U=1,V=1).
\]

No caso independente e simétrico, `P(U=1)=P(V=1)=s` e `rho=s²`, portanto `s=sqrt(rho)` e:

\[
F=\frac{\sqrt\rho}{1-\rho}e^2.
\]

O pacote contém:

- simulador Monte Carlo reprodutível;
- portas independentes, assimétricas e correlacionadas;
- testes automatizados das fórmulas exatas;
- experimentos e resultados em JSON/CSV;
- formalização Lean 4 dos núcleos algébricos FPDP e PI;
- documentação de hipóteses, limites e próximos passos.

## Instalação e execução

```bash
python -m pip install -e .
pytest -q
python scripts/run_experiments.py
```

Os resultados são gravados em `results/monte_carlo_results.json` e `results/monte_carlo_results.csv`.

## Estrutura

```text
src/fpdp/             implementação
scripts/              execução reproduzível
 tests/                testes unitários e de Monte Carlo
lean/                  formalização Lean 4
 docs/                  documentos científicos e guia de continuidade
results/               saídas versionáveis
```

## Status epistemológico

- **Provado analiticamente:** recorrências de segunda ordem e pontos fixos.
- **Validado numericamente:** casos independentes, assimétricos e correlacionados.
- **Formalização Lean:** núcleo algébrico fornecido; compilação local depende de Lean 4 + Mathlib.
- **Não reivindicado:** originalidade externa, universalidade física ou validação empírica em dados reais.
