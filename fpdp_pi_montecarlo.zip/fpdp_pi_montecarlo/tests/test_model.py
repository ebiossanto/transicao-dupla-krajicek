import math
import pytest
from fpdp import (
    GateLaw, theoretical_variances, simulate_double_gate,
    feasible_joint_interval, joint_from_correlation,
)

def test_frechet_interval():
    assert feasible_joint_interval(0.8,0.5)==pytest.approx((0.3,0.5))

def test_independent_symmetric_recovers_square_root_bridge():
    s=0.7; g=GateLaw.independent(s,s)
    th=theoretical_variances(g,p=0.6,e=0.35)
    assert g.rho==pytest.approx(s*s)
    assert th['D']==pytest.approx(g.rho/(1-g.rho)*0.6**2)
    assert th['F']==pytest.approx(math.sqrt(g.rho)/(1-g.rho)*0.35**2)

def test_asymmetric_formula_uses_acquisition_probability():
    g=GateLaw.independent(0.85,0.55)
    th=theoretical_variances(g,p=0.6,e=0.35)
    assert th['F']==pytest.approx(0.85/(1-g.rho)*0.35**2)
    assert not math.isclose(g.s_u, math.sqrt(g.rho))

def test_positive_and_negative_correlation_are_feasible():
    gp=GateLaw.symmetric_correlated(0.7,0.45)
    gn=GateLaw.symmetric_correlated(0.7,-0.35)
    assert gp.rho>0.49
    assert gn.rho<0.49
    assert gp.corr==pytest.approx(0.45)
    assert gn.corr==pytest.approx(-0.35)

def test_infeasible_correlation_rejected():
    with pytest.raises(ValueError): joint_from_correlation(0.95,0.10,-1.0)

@pytest.mark.parametrize('g',[
    GateLaw.independent(0.70,0.70),
    GateLaw.independent(0.85,0.55),
    GateLaw.symmetric_correlated(0.70,0.45),
    GateLaw.symmetric_correlated(0.70,-0.35),
])
def test_monte_carlo_matches_theory(g):
    r=simulate_double_gate(g,0.6,0.35,paths=45000,burn_in=650,seed=123)
    assert r['D_rel_error'] < 0.045
    assert r['F_rel_error'] < 0.045
